package com.example.jotador974.flappybird;

/**
 * Created by Jotador974 on 28/04/2018.
 */


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;
import android.os.Handler;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;

import java.util.Random;



public class GameView extends View {


    // Ceci est notre classe de vue personnalisée
    Handler handler; // Handler est nécessaire pour planifier un runnable après un certains retard
    Runnable runnable;
    final int UPDATE_MILLIS = 30;  // Vitesse du jeu
    Bitmap background;
    Bitmap toptube, bottomtube;
    Display display;
    Point point;
    int dWidth, dHeight; // La largeur et la hauteur de l'appareil respective
    Rect rect;
    // Allons créer un Bitmap pour l'oiseau
    Bitmap[] birds;
    // Nous avons besoin d'une variable integer pour garder une trace de  l'image/frame d'oiseau
    int birdFrame = 0;
    int velocity = 0, gravity = 3; // Jouons autour de ces valeurs
    // Nous devons garder une trace de la position des oiseaux
    int birdX, birdY;
    boolean gameState = false;
    int gap = 400; // Écart entre le tube supérieur et le tube inférieur
    int minTubeOffSet, maxTubeOffSet;
    int numberOfTubes = 4;
    int distanceBetweenTubes;
    /*int tubeX;
    int topTubeY;*/
    int[] tubeX = new int[numberOfTubes];
    int[] topTubeY = new int[numberOfTubes];
    Random random;
    int tubeVelocity = 8;
    int score = 0;
    int scoringTube = 0;
    Intent intent;


    public GameView(Context context) {
        super(context);
        handler = new Handler();
        runnable = new Runnable() {
            @Override
            public void run() {
                invalidate(); // Cela appellera onDraw ()
            }
        };
        // Pour background et l'oiseau
        background = BitmapFactory.decodeResource(getResources(), R.drawable.background);
        toptube = BitmapFactory.decodeResource(getResources(), R.drawable.toptube);
        bottomtube = BitmapFactory.decodeResource(getResources(), R.drawable.bottomtube);
        display = ((Activity) getContext()).getWindowManager().getDefaultDisplay();
        point = new Point();
        display.getSize(point);
        dWidth = point.x;
        dHeight = point.y;
        rect = new Rect(0, 0, dWidth, dHeight);
        birds = new Bitmap[2];
        birds[0] = BitmapFactory.decodeResource(getResources(), R.drawable.bird);
        birds[1] = BitmapFactory.decodeResource(getResources(), R.drawable.bird2);
        birdX = dWidth / 2 - birds[0].getWidth() / 2; // Initialement, l'oiseau sera au centre
        birdY = dHeight / 2 - birds[0].getHeight() / 2;
        // Pour les tubes
        distanceBetweenTubes = dWidth * 3 / 4; // Notre hypothèse
        minTubeOffSet = gap / 2;
        maxTubeOffSet = dHeight - minTubeOffSet - gap;
        random = new Random();

        /* AVANT
            tubeX = dWidth/2 - toptube.getWidth()/2;
            topTubeY = minTubeOffSet + random.nextInt(maxTubeOffSet - minTubeOffSet + 1);
        */

        for (int i = 0; i < numberOfTubes; i++) {
            tubeX[i] = dWidth + i * distanceBetweenTubes; // Pour commencer, les tubes doivent provenir du bord droit de l'écran
            topTubeY[i] = minTubeOffSet + random.nextInt(maxTubeOffSet - minTubeOffSet + 1); //topTubeY variera entre  minTubeOffSet et maxTubeOffSet
        }
    }

    /*   POUR Page SCORE
        // Show Result
        intent = new Intent(getContext(),result.class);
        intent.putExtra("SCORE", score);
        getContext().startActivity(intent);*/


    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        // Nous allons dessiner notre vue à l'intérieur de onDraw ()
        // Dessine background sur canvas
        canvas.drawBitmap(background, null, rect, null); // fixé
        Paint textPaint = new Paint();
        textPaint.setARGB(200, 254, 0, 0);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTextSize(150);
        canvas.drawText(score + "", getWidth() / 2, getHeight()/4 , textPaint);


        if (birdFrame == 0) {
            birdFrame = 1;
        } else {
            birdFrame = 0;
        }

        if (gameState) {
            // L'oiseau devrait être sur l'écran
            if (birdY < dHeight - birds[0].getHeight() || velocity < 0) { // De cette façon, l'oiseau ne va pas au-delà du bord inférieur de l'écran
                velocity += gravity; //Au fur et à mesure que l'oiseau tombe, il devient de plus en plus rapide à mesure que la valeur de la vélocité augmente par gravité à chaque fois
                birdY += velocity;
            }
            if (tubeX[scoringTube] < toptube.getWidth() * 1.7) {
                score++;
                if (scoringTube < numberOfTubes - 1) {
                    scoringTube++;
                } else {
                    scoringTube = 0;
                }
            }
            for (int i = 0; i < numberOfTubes; i++) {
                tubeX[i] -= tubeVelocity;
                if (tubeX[i] < -toptube.getWidth()) {
                    tubeX[i] += numberOfTubes * distanceBetweenTubes;
                    topTubeY[i] = minTubeOffSet + random.nextInt(maxTubeOffSet - minTubeOffSet + 1);
                }
                canvas.drawBitmap(toptube, tubeX[i], topTubeY[i] - toptube.getHeight(), null);
                canvas.drawBitmap(bottomtube, tubeX[i], topTubeY[i] + gap, null);

                // COLLISION SOL
                if (birdY > dHeight - birds[0].getHeight()) {
                    intent = new Intent(getContext(), result.class);
                    intent.putExtra("SCORE", score);
                    getContext().startActivity(intent);
                    System.exit(0);
                }
                // COLLISION PLAFOND
                if (birdY < dWidth/10 - birds[0].getHeight()) {
                    intent = new Intent(getContext(), result.class);
                    intent.putExtra("SCORE", score);
                    getContext().startActivity(intent);
                    System.exit(0);
                }
                // COLLISION TUBES

                if (birdX + birds[0].getWidth() >= tubeX[i] && birdX + birds[0].getWidth()/2 <= tubeX[i] + toptube.getWidth() ){

                    if(birdY + birds[0].getHeight()/10 <= topTubeY[i]){ //Collision tube du haut
                        intent = new Intent(getContext(), result.class);
                        intent.putExtra("SCORE", score);
                        getContext().startActivity(intent);
                        System.exit(0);
                    }
                    if(birdY + birds[0].getHeight()/10 >= topTubeY[i] + bottomtube.getWidth() ){ //tube du bas
                        intent = new Intent(getContext(), result.class);
                        intent.putExtra("SCORE", score);
                        getContext().startActivity(intent);
                        System.exit(0);
                    }

                }

            }
        }


        // Nous voulons que l'oiseau soit affiché au centre de l'écran
        //Les deux oiseaux birds[0] et birds[1] ont la même dimension
        canvas.drawBitmap(birds[birdFrame], birdX, birdY, null);
        handler.postDelayed(runnable, UPDATE_MILLIS);

    }

    // Get the touch event

    @Override
    public boolean onTouchEvent(MotionEvent event) {

        int action = event.getAction();
        if (action == MotionEvent.ACTION_DOWN) { // This is the tap is detected on the screen
            //Ici, nous voulons que l'oiseau se déplace vers le haut par une unité
            velocity = -30; // Disons, 30 unités vers l'intérieur
            gameState = true;
        }

        return true; // En retournant true indique que nous avons fait avec l'événement tactile et aucune autre action n'est requise par Android
    }
}