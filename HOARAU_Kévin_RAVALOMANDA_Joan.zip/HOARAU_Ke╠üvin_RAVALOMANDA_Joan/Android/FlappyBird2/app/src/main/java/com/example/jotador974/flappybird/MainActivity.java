package com.example.jotador974.flappybird;

/**
 * Created by Jotador974 on 28/04/2018.
 */

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final Button B_scores = (Button) findViewById(R.id.B_scores);
        final Button B_quitter = (Button) findViewById(R.id.B_quitter);
        B_scores.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Création de l'ecouteur
                Intent intent = new Intent(MainActivity.this,result.class);
                startActivity(intent);
            }
        });
        B_quitter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Création de l'ecouteur
                finish();
            }
        });


    }

    public void startGame(View view)
    {
        Intent intent = new Intent(this, StartGame.class);
        startActivity(intent);
        finish();
    }
}