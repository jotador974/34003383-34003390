//
//  GameScene.swift
//  Flappy Craft
//
//  Created by RAVALOMANDA Joan on 27/04/2018.
//  Copyright © 2018 RAVALOMANDA Joan. All rights reserved.
//

import SpriteKit

extension GameScene{
    // Création du "bird"
    func createBird() -> SKSpriteNode {
        // 1
        let bird = SKSpriteNode(texture: SKTextureAtlas(named:"player").textureNamed("bird1"))
        bird.size = CGSize(width: 50, height: 50)
        bird.position = CGPoint(x:self.frame.midX, y:self.frame.midY)
        // 2
        bird.physicsBody = SKPhysicsBody(circleOfRadius: bird.size.width / 2)
        bird.physicsBody?.linearDamping = 1.1
        bird.physicsBody?.restitution = 0
        // 3
        bird.physicsBody?.categoryBitMask = CollisionBitMask.birdCategory
        bird.physicsBody?.collisionBitMask = CollisionBitMask.tubeCategory | CollisionBitMask.groundCategory
        bird.physicsBody?.contactTestBitMask = CollisionBitMask.tubeCategory | CollisionBitMask.flowerCategory | CollisionBitMask.groundCategory
        // 4
        bird.physicsBody?.affectedByGravity = false
        bird.physicsBody?.isDynamic = true
        
        return bird
    }
    // Création du bouton "Restart"
    func createRestartButton() {
        restartButton = SKSpriteNode(imageNamed: "restart")
        restartButton.size = CGSize(width:100, height:100)
        restartButton.position = CGPoint(x: self.frame.width / 2, y: self.frame.height / 2)
        restartButton.zPosition = 6
        restartButton.setScale(0)
        self.addChild(restartButton)
        restartButton.run(SKAction.scale(to: 1.0, duration: 0.3))
    }
    // Création du bouton Pause
    func createPauseButton() {
        pauseButton = SKSpriteNode(imageNamed: "pause")
        pauseButton.size = CGSize(width:40, height:40)
        pauseButton.position = CGPoint(x: self.frame.width - 30, y: 30)
        pauseButton.zPosition = 6
        self.addChild(pauseButton)
    }
    // Création du label du score
    func createScoreLabel() -> SKLabelNode {
        let scoreLabel = SKLabelNode()
        scoreLabel.position = CGPoint(x: self.frame.width / 2, y: self.frame.height / 2 + self.frame.height / 2.6)
        scoreLabel.text = "\(score)"
        scoreLabel.zPosition = 5
        scoreLabel.fontSize = 50
        scoreLabel.fontName = "HelveticaNeue-Bold"
        
        let scoreBg = SKShapeNode()
        scoreBg.position = CGPoint(x: 0, y: 0)
        scoreBg.path = CGPath(roundedRect: CGRect(x: CGFloat(-50), y: CGFloat(-30), width: CGFloat(100), height: CGFloat(100)), cornerWidth: 50, cornerHeight: 50, transform: nil)
        let scoreBgColor = UIColor(red: CGFloat(0.0 / 255.0), green: CGFloat(0.0 / 255.0), blue: CGFloat(0.0 / 255.0), alpha: CGFloat(0.2))
        scoreBg.strokeColor = UIColor.clear
        scoreBg.fillColor = scoreBgColor
        scoreBg.zPosition = -1
        scoreLabel.addChild(scoreBg)
        return scoreLabel
    }
    // Création du label du meilleur score
    func createHighscoreLabel() -> SKLabelNode {
        let highscoreLabel = SKLabelNode()
        highscoreLabel.position = CGPoint(x: self.frame.width - 80, y: self.frame.height - 22)
        if let highestScore = UserDefaults.standard.object(forKey: "highestScore"){
            highscoreLabel.text = "Meilleur score: \(highestScore)"
        } else {
            highscoreLabel.text = "Meilleur score: 0"
        }
        highscoreLabel.zPosition = 5
        highscoreLabel.fontSize = 15
        highscoreLabel.fontName = "Helvetica-Bold"
        return highscoreLabel
    }
    // Création du logo de l'accueil
    func createLogo() {
        logoImg = SKSpriteNode()
        logoImg = SKSpriteNode(imageNamed: "logo")
        logoImg.size = CGSize(width: 272, height: 65)
        logoImg.position = CGPoint(x:self.frame.midX, y:self.frame.midY + 100)
        logoImg.setScale(0.5)
        self.addChild(logoImg)
        logoImg.run(SKAction.scale(to: 1.0, duration: 0.3))
    }
    // Création du label pour taper sur l'écran pour démarrer la partie
    func createTaptoplayLabel() -> SKLabelNode {
        let taptoplayLabel = SKLabelNode()
        taptoplayLabel.position = CGPoint(x:self.frame.midX, y:self.frame.midY - 100)
        taptoplayLabel.text = "Tape n'importe où pour jouer"
        taptoplayLabel.fontColor = UIColor(red: 255, green: 255, blue: 255, alpha: 255)
        taptoplayLabel.zPosition = 5
        taptoplayLabel.fontSize = 20
        taptoplayLabel.fontName = "HelveticaNeue"
        return taptoplayLabel
    }
    // Création des murs ou tube, des fleurs
    func createWalls() -> SKNode  {
        // Ici on instancie un noeud fleur comme tout autre noeud. On définie son categoryBitMask à flower et contactBitMask à bird parce qu'on doit détecter les contacts avec l'oiseau.
        let flowerNode = SKSpriteNode(imageNamed: "flower")
        flowerNode.size = CGSize(width: 40, height: 40)
        flowerNode.position = CGPoint(x: self.frame.width + 25, y: self.frame.height / 2)
        flowerNode.physicsBody = SKPhysicsBody(rectangleOf: flowerNode.size)
        flowerNode.physicsBody?.affectedByGravity = false
        flowerNode.physicsBody?.isDynamic = false
        flowerNode.physicsBody?.categoryBitMask = CollisionBitMask.flowerCategory
        flowerNode.physicsBody?.collisionBitMask = 0
        flowerNode.physicsBody?.contactTestBitMask = CollisionBitMask.birdCategory
        flowerNode.color = SKColor.blue
        
        // On crée un objet SKNode nommé wallPair pour y ajouter les tubes supérieur et inférieur en tant qu'enfants. Ensuite, on crée les tubes supérieur et inférieur et on définis leur échelle à 0,5. Cela met à l'échelle les nœuds à la moitié de leur taille, setScale est utilisé pour augmenter ou diminuer la taille de l'image-objet à propos du facteur d'échelle. Comme les mêmes images sont utilisées pour les tubes supérieur et inférieur, on fait pivoter le nœud du tube supérieur de 180 degrés pour que le tube s'oriente correctement. Les tubes sont conçus pour rester immobiles, donc on a affecté leur propriété dynamique à false.
        wallPair = SKNode()
        wallPair.name = "wallPair"
        
        let topWall = SKSpriteNode(imageNamed: "toptube")
        let bottomWall = SKSpriteNode(imageNamed: "bottomtube")
        
        topWall.position = CGPoint(x: self.frame.width + 25, y: self.frame.height / 2 + 420)
        bottomWall.position = CGPoint(x: self.frame.width + 25, y: self.frame.height / 2 - 420)
        
        topWall.setScale(0.5)
        bottomWall.setScale(0.5)
        
        topWall.physicsBody = SKPhysicsBody(rectangleOf: topWall.size)
        topWall.physicsBody?.categoryBitMask = CollisionBitMask.tubeCategory
        topWall.physicsBody?.collisionBitMask = CollisionBitMask.birdCategory
        topWall.physicsBody?.contactTestBitMask = CollisionBitMask.birdCategory
        topWall.physicsBody?.isDynamic = false
        topWall.physicsBody?.affectedByGravity = false
        
        bottomWall.physicsBody = SKPhysicsBody(rectangleOf: bottomWall.size)
        bottomWall.physicsBody?.categoryBitMask = CollisionBitMask.tubeCategory
        bottomWall.physicsBody?.collisionBitMask = CollisionBitMask.birdCategory
        bottomWall.physicsBody?.contactTestBitMask = CollisionBitMask.birdCategory
        bottomWall.physicsBody?.isDynamic = false
        bottomWall.physicsBody?.affectedByGravity = false
        
        topWall.zRotation = CGFloat.pi
        
        wallPair.addChild(topWall)
        wallPair.addChild(bottomWall)
        
        wallPair.zPosition = 1
        
        // Cela générera un nombre aléatoire entre -200 et 200 en utilisant la fonction random () , et ajoutera cette valeur à la position "y" de wallPair . Cela place les wallPairs à des hauteurs aléatoires. Vous appelez ensuite l'action moveAndRemove sur wallPair qui le déplace horizontalement, puis le supprime lorsqu'il atteint l'autre côté de l'écran.
        
        let randomPosition = random(min: -200, max: 200)
        wallPair.position.y = wallPair.position.y +  randomPosition
        wallPair.addChild(flowerNode)
        
        wallPair.run(moveAndRemove)
        
        return wallPair
    }
    
    func random() -> CGFloat{
        return CGFloat(Float(arc4random()) / 0xFFFFFFFF)
    }
    
    func random(min : CGFloat, max : CGFloat) -> CGFloat{
        return random() * (max - min) + min
    }
    
}
