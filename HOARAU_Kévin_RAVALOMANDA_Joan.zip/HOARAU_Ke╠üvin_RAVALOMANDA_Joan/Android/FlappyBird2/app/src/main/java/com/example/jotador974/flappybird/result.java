package com.example.jotador974.flappybird;

/**
 * Created by Jotador974 on 28/04/2018.
 */

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class result extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        TextView scoreLabel = (TextView) findViewById(R.id.scoreLabel);
        TextView highScoreLabel = (TextView) findViewById(R.id.highScoreLabel);
        // Initialisation du bouton Rejouer et Quitter
        final Button B_rejouer = (Button) findViewById(R.id.B_rejouer);
        final Button B_quitter = (Button) findViewById(R.id.B_quitter);
        final Button B_accueil = (Button) findViewById(R.id.B_accueil);

        int score = getIntent().getIntExtra("SCORE", 0);
        scoreLabel.setText(score + "");

        SharedPreferences settings = getSharedPreferences("GAME_DATA", Context.MODE_PRIVATE);
        int highScore = settings.getInt("HIGH SCORE", 0);

        if(score > highScore){
            highScoreLabel.setText("High Score : " + score);

            //Save
            SharedPreferences.Editor editor = settings.edit();
            editor.putInt("HIGH SCORE", score);
            editor.commit();

        }else{
            highScoreLabel.setText("High Score : " + highScore);
        }
        //Bouton rejouer listener
        B_rejouer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Création de l'ecouteur
                Intent intent = new Intent(result.this,StartGame.class);
                startActivity(intent);
            }
        });
        //Bouton quitter listener
        B_quitter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.exit(0);
            }
        });
        //Bouton accueil listener
        B_accueil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(result.this,MainActivity.class);
                startActivity(intent);
            }
        });

    }
}