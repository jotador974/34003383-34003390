//
//  GameElements.swift
//  Flappy Craft
//
//  Created by RAVALOMANDA Joan on 27/04/2018.
//  Copyright © 2018 RAVALOMANDA Joan. All rights reserved.
//

import SpriteKit

struct CollisionBitMask {
    // Assignation des catégories aux corps de physique qu'on créera plus tard dans le jeu.
    // Chaque corps physique d'une scène peut être affecté à 32 catégories différentes,
    // chacune correspondant à un bit dans le masque de bits. Avec ces catégories assignées,
    // on définiera plus tard quels corps physiques interagissent entre eux et quand le jeu est averti de ces interactions.
    static let birdCategory:UInt32 = 0x1 << 0
    static let tubeCategory:UInt32 = 0x1 << 1
    static let flowerCategory:UInt32 = 0x1 << 2
    static let groundCategory:UInt32 = 0x1 << 3
}

class GameScene: SKScene, SKPhysicsContactDelegate {
    
    var gameStarted = Bool(false)
    var died = Bool(false)
    let coinSound = SKAction.playSoundFileNamed("CoinSound.mp3", waitForCompletion: false)
    
    var score = Int(0)
    var scoreLabel = SKLabelNode()        //Label du score
    var highscoreLabel = SKLabelNode()    //Label du meilleur score
    var taptoplayLabel = SKLabelNode()    //Label pour play
    var restartButton = SKSpriteNode()    //Bouton pour recommencer
    var pauseButton = SKSpriteNode()      //Bouton pour faire pause
    var resetButton = SKSpriteNode()      //Bouton pour effacer le highscore
    var logoImg = SKSpriteNode()          //image du logo
    var wallPair = SKNode()               //image des tubes
    var moveAndRemove = SKAction()        //action de l'oiseau
    
    //Création de l'animation de l'oiseau
    let birdAtlas = SKTextureAtlas(named:"player")
    var birdSprites = Array<SKTexture>()
    var bird = SKSpriteNode()
    var repeatActionbird = SKAction()
    
    override func didMove(to view: SKView) {
        createScene()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if gameStarted == false{
            gameStarted =  true
            bird.physicsBody?.affectedByGravity = true
            createPauseButton()
            logoImg.run(SKAction.scale(to: 0.5, duration: 0.3), completion: {
                self.logoImg.removeFromParent()
            })
            taptoplayLabel.removeFromParent()
            self.bird.run(repeatActionbird)
            //Exécute une action qui crée et ajoute des paires de tube à la scène.
            let spawn = SKAction.run({
                () in
                self.wallPair = self.createWalls()
                self.addChild(self.wallPair)
            })
            // Vous attendez 1,5 secondes pour que le prochain ensemble de tube soit généré. Une séquence d'actions exécutera le spawn et retardera les actions pour toujours.
            let delay = SKAction.wait(forDuration: 1.5)
            let SpawnDelay = SKAction.sequence([spawn, delay])
            let spawnDelayForever = SKAction.repeatForever(SpawnDelay)
            self.run(spawnDelayForever)
            // Cela va déplacer et enlever les tubes. On définis la distance que doivent parcourir les tubes, qui est la somme de l'écran et de la largeur du tube. Une autre séquence d'action sera exécutée pour déplacer et retirer les tubes. Les tubes commencent à se déplacer vers la gauche de l'écran au fur et à mesure qu'ils sont créés et sont désalloués lorsqu'ils sortent de l'écran.
            let distance = CGFloat(self.frame.width + wallPair.frame.width)
            let movePipes = SKAction.moveBy(x: -distance - 50, y: 0, duration: TimeInterval(0.008 * distance))
            let removePipes = SKAction.removeFromParent()
            moveAndRemove = SKAction.sequence([movePipes, removePipes])
            
            bird.physicsBody?.velocity = CGVector(dx: 0, dy: 0)
            bird.physicsBody?.applyImpulse(CGVector(dx: 0, dy: 40))
        } else {
            if died == false {
                bird.physicsBody?.velocity = CGVector(dx: 0, dy: 0)
                bird.physicsBody?.applyImpulse(CGVector(dx: 0, dy: 40))
            }
        }
        
        
        for touch in touches{
            let location = touch.location(in: self)
            // Ici, nous vérifions l'emplacement des touches pour voir si elles sont contenues dans les boutons de redémarrage ou de pause . Si le jeu se termine (oiseau est mort) alors l'utilisateur est seulement autorisé à interagir avec le bouton de redémarrage. Lorsque vous appuyez sur le bouton de redémarrage, vous obtenez le score le plus élevé enregistré dans UserDefaults . Si le résultat est inférieur au score le plus récent, vous définissez le score le plus élevé. Sinon, vous le définissez sur zéro. Premier jeu)
            if died == true{
                if restartButton.contains(location){
                    if UserDefaults.standard.object(forKey: "highestScore") != nil {
                        let hscore = UserDefaults.standard.integer(forKey: "highestScore")
                        if hscore < Int(scoreLabel.text!)!{
                            UserDefaults.standard.set(scoreLabel.text, forKey: "highestScore")
                        }
                    } else {
                        UserDefaults.standard.set(0, forKey: "highestScore")
                    }
                    restartScene()
                }
            } else {
                //Si le joueur n'est pas mort c'est-à-dire que le jeu est en pause, alors vous mettez le jeu en pause et changez la texture du bouton de pause pour l'image nommée play et quand vous le touchez à nouveau le jeu.
                if pauseButton.contains(location){
                    if self.isPaused == false{
                        self.isPaused = true
                        pauseButton.texture = SKTexture(imageNamed: "play")
                    } else {
                        self.isPaused = false
                        pauseButton.texture = SKTexture(imageNamed: "pause")
                    }
                    
                }
            }
        }
    }
    
    // La fonction ci-dessous va supprimer tous les nœuds de la scène et arrêter toutes les actions en cours. On définisse isDied et isGameStarted sur false et le score est nul, enfin on appele la fonction createScene pour reconstruire la scène de jeu.
    func restartScene(){
        self.removeAllChildren()
        self.removeAllActions()
        died = false
        gameStarted = false
        score = 0
        createScene()
    }
    
    
    func createScene(){
        self.physicsBody = SKPhysicsBody(edgeLoopFrom: self.frame)
        self.physicsBody?.categoryBitMask = CollisionBitMask.groundCategory
        self.physicsBody?.collisionBitMask = CollisionBitMask.birdCategory
        self.physicsBody?.contactTestBitMask = CollisionBitMask.birdCategory
        self.physicsBody?.isDynamic = false
        self.physicsBody?.affectedByGravity = false
        
        self.physicsWorld.contactDelegate = self
        self.backgroundColor = SKColor(red: 80.0/255.0, green: 192.0/255.0, blue: 203.0/255.0, alpha: 1.0)
        
        for i in 0..<2 {
            let background = SKSpriteNode(imageNamed: "bg")
            background.anchorPoint = CGPoint.init(x: 0, y: 0)
            background.position = CGPoint(x:CGFloat(i) * self.frame.width, y:0)
            background.name = "background"
            background.size = (self.view?.bounds.size)!
            self.addChild(background)
        }
        
        //Installation des sprites d'oiseaux pour l'animation
        birdSprites.append(birdAtlas.textureNamed("bird1"))
        birdSprites.append(birdAtlas.textureNamed("bird2"))
        
        self.bird = createBird()
        self.addChild(bird)
        
        //Animation de l'oiseau et répétition de l'animation pour toujours
        let animatebird = SKAction.animate(with: self.birdSprites, timePerFrame: 0.1)
        self.repeatActionbird = SKAction.repeatForever(animatebird)
        
        scoreLabel = createScoreLabel()
        self.addChild(scoreLabel)
        
        highscoreLabel = createHighscoreLabel()
        self.addChild(highscoreLabel)
        
        createLogo()
        
        taptoplayLabel = createTaptoplayLabel()
        self.addChild(taptoplayLabel)
    }
    // Le paramètre de contact contient une référence aux deux corps qui entrent en collision. On identifie les deux corps en comparant leur propriété categoryBitMask . Dans ce bloc, on vérifie si les deux corps en collision sont l'oiseau et le tube, ou l'oiseau et le sol. Dans les deux cas, vous arrêtez le jeu
    func didBegin(_ contact: SKPhysicsContact) {
        let firstBody = contact.bodyA
        let secondBody = contact.bodyB
        
        if firstBody.categoryBitMask == CollisionBitMask.birdCategory && secondBody.categoryBitMask == CollisionBitMask.tubeCategory || firstBody.categoryBitMask == CollisionBitMask.tubeCategory && secondBody.categoryBitMask == CollisionBitMask.birdCategory || firstBody.categoryBitMask == CollisionBitMask.birdCategory && secondBody.categoryBitMask == CollisionBitMask.groundCategory || firstBody.categoryBitMask == CollisionBitMask.groundCategory && secondBody.categoryBitMask == CollisionBitMask.birdCategory{
            enumerateChildNodes(withName: "wallPair", using: ({
                (node, error) in
                node.speed = 0
                self.removeAllActions()
            }))
            if died == false{
                died = true
                createRestartButton()
                pauseButton.removeFromParent()
                self.bird.removeAllActions()
            }
        } else if firstBody.categoryBitMask == CollisionBitMask.birdCategory && secondBody.categoryBitMask == CollisionBitMask.flowerCategory {
            run(coinSound)
            score += 1
            scoreLabel.text = "\(score)"
            secondBody.node?.removeFromParent()
        } else if firstBody.categoryBitMask == CollisionBitMask.flowerCategory && secondBody.categoryBitMask == CollisionBitMask.birdCategory {
            run(coinSound)
            score += 1
            scoreLabel.text = "\(score)"
            firstBody.node?.removeFromParent()
        }
    }
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
        if gameStarted == true{
            if died == false{
                enumerateChildNodes(withName: "background", using: ({
                    (node, error) in
                    let bg = node as! SKSpriteNode
                    bg.position = CGPoint(x: bg.position.x - 2, y: bg.position.y)
                    if bg.position.x <= -bg.size.width {
                        bg.position = CGPoint(x:bg.position.x + bg.size.width * 2, y:bg.position.y)
                    }
                    
                }))
            }
        }
    }
}
